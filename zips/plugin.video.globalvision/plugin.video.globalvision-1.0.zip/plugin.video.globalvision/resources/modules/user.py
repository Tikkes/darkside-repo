import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmdsb2JhbHZpc2lvbg==')

name = b.b64decode('R1ZF')

host = b.b64decode('aHR0cDovL2dsb2JhbHZpc2lvbi5zdG9yZQ==')

port = b.b64decode('MjU0NjE=')